package com.backend.workitwise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkitwiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
