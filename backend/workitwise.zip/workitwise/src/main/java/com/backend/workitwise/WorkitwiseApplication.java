package com.backend.workitwise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkitwiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkitwiseApplication.class, args);
	}

}
